const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/restaurant_db')
  .then(() => console.log('MongoDB connecté'))
  .catch((err) => console.error('Erreur MongoDB :', err));

// Schéma utilisateur
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, required: true },
  password: String,
});

const User = mongoose.model('User', userSchema);

// Schéma admin (facultatif)
const adminSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
});
const Admin = mongoose.model('Admin', adminSchema);

// Inscription utilisateur
app.post('/api/users', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    console.log("Données reçues :", req.body);

    // Vérifier si l'email existe déjà
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email déjà utilisé.' });
    }

    const newUser = new User({ name, email, password });
    await newUser.save();
    res.status(201).json({ message: 'Utilisateur inscrit avec succès !' });
  } catch (err) {
    console.error("Erreur lors de l'inscription :", err);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// Récupération des utilisateurs
app.get('/api/users', async (req, res) => {
  try {
    const users = await User.find({});
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// Suppression d'un utilisateur
app.delete('/api/users/:id', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Utilisateur supprimé' });
  } catch (err) {
    res.status(500).json({ message: 'Erreur lors de la suppression' });
  }
});

// Connexion admin (version simple)
app.post('/api/admin/login', async (req, res) => {
  const { name, email, password } = req.body;

  if (
    name === 'Felix' &&
    email === 'felixthiopfaye@esp.sn' &&
    password === 'admin123'
  ) {
    return res.status(200).json({ message: 'Connexion admin réussie' });
  }

  res.status(401).json({ message: 'Identifiants admin incorrects' });
});

// Lancer le serveur
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`);
});
