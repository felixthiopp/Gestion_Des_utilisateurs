const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Inscription utilisateur
router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const existing = await User.findOne({ email });
        if (existing) return res.status(400).json({ message: "Adresse déjà utilisée" });

        const user = new User({ name, email, password });
        await user.save();
        res.status(201).json({ message: "Inscription réussie" });
    } catch (err) {
        res.status(500).json({ message: "Erreur serveur" });
    }
});

// Connexion admin
router.post('/admin/login', (req, res) => {
    const { name, email, password } = req.body;
    if (name === "Felix" && email === "felixthiopfaye@esp.sn" && password === "admin123") {
        req.session.admin = true;
        return res.json({ message: "Connexion réussie" });
    }
    res.status(401).json({ message: "Identifiants incorrects" });
});

// Liste des inscrits (admin uniquement)
router.get('/admin/users', async (req, res) => {
    if (!req.session.admin) return res.status(403).json({ message: "Non autorisé" });
    const users = await User.find();
    res.json(users);
});

// Supprimer un inscrit
router.delete('/admin/users/:id', async (req, res) => {
    if (!req.session.admin) return res.status(403).json({ message: "Non autorisé" });
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: "Utilisateur supprimé" });
});

// Déconnexion admin
router.post('/admin/logout', (req, res) => {
    req.session.destroy(() => {
        res.json({ message: "Déconnecté" });
    });
});

module.exports = router;
