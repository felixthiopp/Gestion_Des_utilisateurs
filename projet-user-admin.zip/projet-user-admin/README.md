# Projet : Système d'inscription utilisateur et gestion admin

Ce projet est une application web simple avec un backend Node.js + Express + MongoDB et un frontend HTML/CSS/JavaScript.

## ✨ Fonctionnalités

### Côté Utilisateur
- Formulaire d'inscription avec les champs : **nom**, **email**, **mot de passe**
- Message d'erreur si l'email est déjà utilisé

### Côté Admin
- Page de connexion admin (HTML séparé)
- Connexion possible uniquement avec :
  - Nom : Felix
  - Email : felixthiopfaye@esp.sn
  - Mot de passe : admin123
- Une fois connecté, l'admin :
  - Voit la liste des utilisateurs inscrits
  - Peut supprimer un utilisateur
  - Reste sur la page admin tant qu’il ne se déconnecte pas

## 🧰 Technologies utilisées

- Backend : Node.js, Express, MongoDB, Mongoose
- Frontend : HTML, CSS, JavaScript
- Tests d'API possibles via Thunder Client ou Postman

## 📁 Structure du projet

```
/models
  User.js
/routes
  userRoutes.js
  adminRoutes.js
/views
  index.html
  admin.html
app.js
README.md
```

## ⚙️ Installation et exécution

1. **Cloner le dépôt**
```bash
git clone https://github.com/ton-utilisateur/ton-projet.git
cd ton-projet
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Configurer la base de données**
Assure-toi que MongoDB tourne localement ou utilise MongoDB Atlas.
Modifie la chaîne de connexion dans `app.js` si besoin :
```js
mongoose.connect('mongodb://localhost:27017/nom_de_ta_db');
```

4. **Démarrer le serveur**
```bash
node app.js
```

5. **Accéder à l'application**
- Page d'inscription : http://localhost:3000/
- Page admin : http://localhost:3000/admin.html

## ✅ Informations importantes

- Les emails dupliqués sont bloqués lors de l'inscription
- Le compte admin est codé en dur (non modifiable par l'utilisateur)
- Aucune base de données n'est accessible via l’interface utilisateur

## 🔐 Accès admin par défaut

| Nom   | Email                    | Mot de passe |
|-------|--------------------------|--------------|
| Felix | felixthiopfaye@esp.sn    | admin123     |

---


